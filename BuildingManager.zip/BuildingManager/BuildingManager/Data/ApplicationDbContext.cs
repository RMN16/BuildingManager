﻿using BuildingManager.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BuildingManager.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Signal> Signals { get; set; }
        public DbSet<Tax> Taxes { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Announcement> Announcements { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            // Може да добавите допълнителни конфигурации тук, ако е необходимо
            builder.Entity<Payment>()
                .HasOne(p => p.Tax)
                .WithMany(t => t.Payments)
                .HasForeignKey(p => p.TaxId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}