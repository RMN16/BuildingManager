﻿using Microsoft.AspNetCore.Identity;

namespace BuildingManager.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string? ApartmentNumber { get; set; }
    }
}