﻿namespace BuildingManager.Models
{
    public class Payment
    {
        public int Id { get; set; }
        public int TaxId { get; set; }
        public Tax? Tax { get; set; }
        public string UserId { get; set; } = string.Empty;
        public ApplicationUser? User { get; set; }
        public DateTime PaidAt { get; set; } = DateTime.Now;
        public decimal AmountPaid { get; set; }
        public bool IsSuccessful { get; set; } = true;
    }
}