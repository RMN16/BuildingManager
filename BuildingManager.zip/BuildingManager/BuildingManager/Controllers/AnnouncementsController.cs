﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BuildingManager.Data;
using BuildingManager.Models;

namespace BuildingManager.Controllers
{
    [Authorize]  // само логнати потребители
    public class AnnouncementsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public AnnouncementsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Announcements - достъпно за всички логнати
        public async Task<IActionResult> Index()
        {
            var announcements = _context.Announcements
                .Include(a => a.CreatedByUser)
                .OrderByDescending(a => a.CreatedAt);
            return View(await announcements.ToListAsync());
        }

        // GET: Announcements/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var announcement = await _context.Announcements
                .Include(a => a.CreatedByUser)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (announcement == null) return NotFound();
            return View(announcement);
        }

        // GET: Announcements/Create - само за Председател/Админ
        [Authorize(Roles = "Председател,Админ")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Announcements/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Create([Bind("Title,Content")] Announcement announcement)
        {
            if (ModelState.IsValid)
            {
                announcement.CreatedAt = DateTime.Now;
                announcement.CreatedByUserId = _userManager.GetUserId(User);
                _context.Add(announcement);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Обявлението е публикувано.";
                return RedirectToAction(nameof(Index));
            }
            return View(announcement);
        }

        // GET: Announcements/Edit/5
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var announcement = await _context.Announcements.FindAsync(id);
            if (announcement == null) return NotFound();
            return View(announcement);
        }

        // POST: Announcements/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Content")] Announcement announcement)
        {
            if (id != announcement.Id) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    var existing = await _context.Announcements.FindAsync(id);
                    if (existing == null) return NotFound();
                    existing.Title = announcement.Title;
                    existing.Content = announcement.Content;
                    // Не променяме CreatedAt и CreatedByUserId
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Обявлението е обновено.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AnnouncementExists(announcement.Id)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(announcement);
        }

        // GET: Announcements/Delete/5
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var announcement = await _context.Announcements
                .FirstOrDefaultAsync(m => m.Id == id);
            if (announcement == null) return NotFound();
            return View(announcement);
        }

        // POST: Announcements/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var announcement = await _context.Announcements.FindAsync(id);
            if (announcement != null)
            {
                _context.Announcements.Remove(announcement);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Обявлението е изтрито.";
            }
            return RedirectToAction(nameof(Index));
        }

        private bool AnnouncementExists(int id)
        {
            return _context.Announcements.Any(e => e.Id == id);
        }
    }
}