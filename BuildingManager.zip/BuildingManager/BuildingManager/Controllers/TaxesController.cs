﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BuildingManager.Data;
using BuildingManager.Models;

namespace BuildingManager.Controllers
{
    [Authorize]
    public class TaxesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public TaxesController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Taxes
        public async Task<IActionResult> Index()
        {
            var userId = _userManager.GetUserId(User);
            var taxes = await _context.Taxes
                .Include(t => t.CreatedByUser)
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();

            // Създава речник с ID на такса -> дали текущият потребител е платил
            var paymentStatus = new Dictionary<int, bool>();
            foreach (var tax in taxes)
            {
                bool isPaid = await _context.Payments
                    .AnyAsync(p => p.TaxId == tax.Id && p.UserId == userId);
                paymentStatus[tax.Id] = isPaid;
            }

            ViewBag.PaymentStatus = paymentStatus;
            return View(taxes);
        }

        // GET: Taxes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
                return NotFound();

            var tax = await _context.Taxes
                .Include(t => t.CreatedByUser)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (tax == null)
                return NotFound();

            return View(tax);
        }

        // GET: Taxes/Create (само за Председател и Админ)
        [Authorize(Roles = "Председател,Админ")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Taxes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Create([Bind("Name,Amount,DueDate")] Tax tax)
        {
            if (ModelState.IsValid)
            {
                tax.CreatedByUserId = _userManager.GetUserId(User);
                tax.CreatedAt = DateTime.Now;
                _context.Add(tax);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Таксата е създадена успешно.";
                return RedirectToAction(nameof(Index));
            }
            return View(tax);
        }

        // GET: Taxes/Edit/5 (само за Председател и Админ)
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var tax = await _context.Taxes.FindAsync(id);
            if (tax == null) return NotFound();
            return View(tax);
        }

        // POST: Taxes/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Amount,DueDate")] Tax tax)
        {
            if (id != tax.Id) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    var existing = await _context.Taxes.FindAsync(id);
                    if (existing == null) return NotFound();
                    existing.Name = tax.Name;
                    existing.Amount = tax.Amount;
                    existing.DueDate = tax.DueDate;
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Таксата е редактирана.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Taxes.Any(e => e.Id == id)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(tax);
        }

        // POST: Taxes/Pay
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Pay(int id)
        {
            var tax = await _context.Taxes.FindAsync(id);
            if (tax == null) return NotFound();

            var userId = _userManager.GetUserId(User);
            var alreadyPaid = await _context.Payments
                .AnyAsync(p => p.TaxId == id && p.UserId == userId);

            if (alreadyPaid)
            {
                TempData["Error"] = "Вече сте платили тази такса.";
                return RedirectToAction(nameof(Index));
            }

            var payment = new Payment
            {
                TaxId = id,
                UserId = userId,
                AmountPaid = tax.Amount,
                PaidAt = DateTime.Now,
                IsSuccessful = true
            };
            _context.Payments.Add(payment);
            await _context.SaveChangesAsync();

            TempData["Success"] = "Плащането е успешно!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Taxes/Delete/5 (само за Председател и Админ)
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var tax = await _context.Taxes.FindAsync(id);
            if (tax == null) return NotFound();
            return View(tax);
        }

        // POST: Taxes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var tax = await _context.Taxes.FindAsync(id);
            if (tax != null)
            {
                _context.Taxes.Remove(tax);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Таксата е изтрита.";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}