﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BuildingManager.Data;
using BuildingManager.Models;

namespace BuildingManager.Controllers
{
    [Authorize]  // Само логнати потребители
    public class SignalsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public SignalsController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Signals
        public async Task<IActionResult> Index()
        {
            var signals = _context.Signals
                .Include(s => s.User)
                .Include(s => s.CompletedByUser)
                .OrderByDescending(s => s.CreatedAt);
            return View(await signals.ToListAsync());
        }

        // GET: Signals/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            var signal = await _context.Signals
                .Include(s => s.User)
                .Include(s => s.CompletedByUser)
                .FirstOrDefaultAsync(s => s.Id == id);
            if (signal == null) return NotFound();
            return View(signal);
        }

        // GET: Signals/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Signals/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Title,Description")] Signal signal)
        {
            if (ModelState.IsValid)
            {
                signal.UserId = _userManager.GetUserId(User);
                signal.IsCompleted = false;
                signal.CreatedAt = DateTime.Now;
                _context.Add(signal);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Сигналът е изпратен успешно.";
                return RedirectToAction(nameof(Index));
            }
            return View(signal);
        }

        // GET: Signals/Edit/5
        [Authorize(Roles = "Админ")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var signal = await _context.Signals.FindAsync(id);
            if (signal == null) return NotFound();
            return View(signal);
        }

        // POST: Signals/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Админ")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Description,IsCompleted")] Signal signal)
        {
            if (id != signal.Id) return NotFound();
            if (ModelState.IsValid)
            {
                try
                {
                    var existing = await _context.Signals.FindAsync(id);
                    if (existing == null) return NotFound();
                    existing.Title = signal.Title;
                    existing.Description = signal.Description;
                    existing.IsCompleted = signal.IsCompleted;
                    if (existing.IsCompleted && existing.CompletedAt == null)
                    {
                        existing.CompletedAt = DateTime.Now;
                        existing.CompletedByUserId = _userManager.GetUserId(User);
                    }
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Сигналът е редактиран.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SignalExists(signal.Id)) return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(signal);
        }

        // GET: Signals/Delete/5
        [Authorize(Roles = "Админ")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var signal = await _context.Signals
                .Include(s => s.User)
                .FirstOrDefaultAsync(s => s.Id == id);
            if (signal == null) return NotFound();
            return View(signal);
        }

        // POST: Signals/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Админ")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var signal = await _context.Signals.FindAsync(id);
            if (signal != null)
            {
                _context.Signals.Remove(signal);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Сигналът е изтрит.";
            }
            return RedirectToAction(nameof(Index));
        }

        // POST: Signals/MarkAsCompleted/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Председател,Админ")]
        public async Task<IActionResult> MarkAsCompleted(int id)
        {
            var signal = await _context.Signals.FindAsync(id);
            if (signal != null && !signal.IsCompleted)
            {
                signal.IsCompleted = true;
                signal.CompletedAt = DateTime.Now;
                signal.CompletedByUserId = _userManager.GetUserId(User);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Сигналът е маркиран като завършен.";
            }
            return RedirectToAction(nameof(Index));
        }

        private bool SignalExists(int id)
        {
            return _context.Signals.Any(e => e.Id == id);
        }
    }
}