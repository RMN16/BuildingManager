using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BuildingManager.Views.Taxes
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
