using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BuildingManager.Views.Taxes
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
