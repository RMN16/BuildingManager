using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BuildingManager.Views.Taxes
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
