using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BuildingManager.Views.Announcements
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
