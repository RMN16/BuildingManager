using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BuildingManager.Views.Announcements
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
