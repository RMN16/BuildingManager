using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BuildingManager.Views.Signals
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
