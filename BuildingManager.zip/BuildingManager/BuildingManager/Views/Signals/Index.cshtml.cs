using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BuildingManager.Views.Signals
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
